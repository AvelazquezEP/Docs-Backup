const reviewsSpanish = () => {
    /* Get the text field */
    var copyText = document.getElementById("AEPSpanish");

    /* Select the text field */
    // copyText.select();
    // copyText.setSelectionRange(0, 99999); /* For mobile devices */

    /* Copy the text inside the text field */
    navigator.clipboard.writeText(copyText.getAttribute("href"));

    /* Alert the copied text */
    // alert("Copied the text: " + copyText.value);

    // evt.preventDefault();
    // navigator.clipboard.writeText(evt.target.getAttribute('href')).then(() => {
    //     /* clipboard successfully set */
    // }, () => {
    //     /* clipboard write failed */
    // });
}
